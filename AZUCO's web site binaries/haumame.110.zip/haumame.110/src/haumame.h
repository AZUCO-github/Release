/***************************************************************************

	HAUMAME
		Rapid Fire
		ExButton

	AZUCO
		url	http://www.smallnews.net/azuco/
		e-mail	azuco@smallnews.net

	r061119	first release

****************************************************************************

#ifndef	HAUMAME_DEF
#define	HAUMAME_DEF

#define	HAU_RAPID_MAX_PLAYER	2
#define	HAU_RAPID_MAX_BUTTON	16
#define	HAU_RAPID_MAX	HAU_RAPID_MAX_PLAYER*HAU_RAPID_MAX_BUTTON

#endif
